
import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
export const ExpenseContext = createContext();
const STORAGE_KEY = 'EXPENSES_V1';
export const Provider = ({children})=>{
  const [expenses, setExpenses] = useState([]);
  useEffect(()=>{ load(); },[]);
  const load = async()=>{
    try{
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if(raw) setExpenses(JSON.parse(raw));
    }catch(e){ console.warn(e); }
  };
  const save = async(next)=>{
    setExpenses(next);
    try{ await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next)); }catch(e){ console.warn(e); }
  };
  const addExpense = async(item)=>{
    const next = [item, ...expenses];
    await save(next);
  };
  const updateExpense = async(id, updated)=>{
    const next = expenses.map(e=> e.id===id? {...e, ...updated} : e);
    await save(next);
  };
  const deleteExpense = async(id)=>{
    const next = expenses.filter(e=> e.id!==id);
    await save(next);
  };
  return <ExpenseContext.Provider value={{expenses, addExpense, updateExpense, deleteExpense}}>{children}</ExpenseContext.Provider>;
};
export default Provider;
