
import React, { useContext } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { ExpenseContext } from '../state/ExpenseProvider';
export default function ExpenseList({navigation}){
  const { expenses } = useContext(ExpenseContext);
  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.addBtn} onPress={()=>navigation.navigate('AddExpense')}>
        <Text style={styles.addTxt}>+ Add</Text>
      </TouchableOpacity>
      <FlatList data={expenses} keyExtractor={i=>i.id} renderItem={({item})=>(
        <TouchableOpacity style={styles.row}>
          <View>
            <Text style={styles.title}>{item.category} — ₹{item.amount}</Text>
            <Text style={styles.sub}>{item.date} • {item.purpose || ''}</Text>
          </View>
        </TouchableOpacity>
      )} />
    </View>
  );
}
const styles = StyleSheet.create({
  container:{flex:1, padding:12, backgroundColor:'#fff'},
  addBtn:{backgroundColor:'#1976D2', padding:12, borderRadius:8, alignSelf:'flex-end', marginBottom:8},
  addTxt:{color:'#fff', fontWeight:'600'},
  row:{padding:12, borderBottomWidth:1, borderBottomColor:'#eee'},
  title:{fontWeight:'600'},
  sub:{color:'#666'}
});
