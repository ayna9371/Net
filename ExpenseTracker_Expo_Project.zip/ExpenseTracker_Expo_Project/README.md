
# Expense Tracker (Expo React Native)

This is a starter Expo project for the Expense Tracker app described by the user.
Features implemented in this starter:
- Expense data entry (categories, date, purpose)
- Local Conveyance auto-calculation at ₹4/km
- Capture / pick receipt images (uses expo-image-picker)
- Store expenses locally using AsyncStorage
- Generate a basic Excel workbook (6 sheets) using xlsx and share it
- Material blue theme (#1976D2)
- Portrait-first layout

## How to run locally
1. Install Node.js and Yarn/npm.
2. Install Expo CLI: `npm install -g expo-cli` (or use `npx expo`).
3. From project root:
   ```
   npm install
   expo start
   ```
4. Use Expo Go to test on a device or run `expo run:android` for a local build (requires Android setup).

## How to produce a standalone APK (recommended: EAS Build)
1. Install EAS CLI: `npm install -g eas-cli`
2. Login with `eas login` (you need an Expo account).
3. Configure project: `eas build:configure`
4. Build Android APK: `eas build -p android --profile production`
5. After build completes, download the artifact from Expo.
(You can also produce an AAB if preferred.)

## Notes & next steps
- The Excel export creates simple sheets. To match your provided reimbursement format exactly, please upload the sample XLSX or tell me which columns must match; I will integrate exact formatting and formulas.
- To turn this into a production-ready app: add input validation, secure image handling, remove dev dependencies, add icons, better navigation and edit/delete flows.
