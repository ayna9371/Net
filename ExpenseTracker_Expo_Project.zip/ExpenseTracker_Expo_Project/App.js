
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import ExpenseList from './src/screens/ExpenseList';
import AddExpense from './src/screens/AddExpense';
import { Provider } from './src/state/ExpenseProvider';
import { StatusBar } from 'expo-status-bar';
export default function App(){
  const Stack = createNativeStackNavigator();
  return (
    <Provider>
      <NavigationContainer>
        <Stack.Navigator screenOptions={{headerStyle:{backgroundColor:'#1976D2'}, headerTintColor:'#fff'}}>
          <Stack.Screen name="Expenses" component={ExpenseList} />
          <Stack.Screen name="AddExpense" component={AddExpense} options={{title:'Add Expense'}} />
        </Stack.Navigator>
      </NavigationContainer>
      <StatusBar style="light" />
    </Provider>
  );
}
