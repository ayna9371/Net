
import React, { useState, useContext } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Alert } from 'react-native';
import { ExpenseContext } from '../state/ExpenseProvider';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { generateExcel } from '../utils/excel';
import uuid from 'react-native-uuid';
export default function AddExpense({navigation}){
  const { addExpense } = useContext(ExpenseContext);
  const [date, setDate] = useState(new Date().toISOString().slice(0,10));
  const [category, setCategory] = useState('Other');
  const [amount, setAmount] = useState('');
  const [purpose, setPurpose] = useState('');
  const [km, setKm] = useState('');
  const [images, setImages] = useState([]);
  const pickImage = async ()=>{
    const res = await ImagePicker.launchImageLibraryAsync({quality:0.7, allowsMultipleSelection:false});
    if(!res.cancelled) setImages([...images, res.uri]);
  };
  const takePhoto = async ()=>{
    const res = await ImagePicker.launchCameraAsync({quality:0.7});
    if(!res.cancelled) setImages([...images, res.uri]);
  };
  const add = async()=>{
    const id = uuid.v4();
    const numericAmount = Number(amount) || (category==='Local Conveyance' && km? (Number(km)*4) : 0);
    const item = { id, date, category, amount: numericAmount, purpose, km: category==='Local Conveyance'? km : undefined, images };
    await addExpense(item);
    Alert.alert('Saved','Expense saved locally');
    navigation.goBack();
  };
  const exportNow = async()=>{
    const res = await generateExcel(); 
    Alert.alert('Export', 'Excel file created at: ' + res);
  };
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.label}>Date</Text>
      <TextInput value={date} onChangeText={setDate} style={styles.input} />
      <Text style={styles.label}>Category</Text>
      <TextInput value={category} onChangeText={setCategory} style={styles.input} />
      <Text style={styles.label}>Purpose</Text>
      <TextInput value={purpose} onChangeText={setPurpose} style={styles.input} />
      {category==='Local Conveyance' && <>
        <Text style={styles.label}>Kilometers (km)</Text>
        <TextInput keyboardType="numeric" value={km} onChangeText={setKm} style={styles.input} />
        <Text style={{marginBottom:8}}>Auto ₹4/km → ₹{km? (Number(km)*4).toFixed(2):'0.00'}</Text>
      </>}
      <Text style={styles.label}>Amount (₹)</Text>
      <TextInput keyboardType="numeric" value={amount} onChangeText={setAmount} style={styles.input} />
      <View style={{flexDirection:'row', gap:8}}>
        <TouchableOpacity style={styles.btn} onPress={pickImage}><Text style={styles.btnTxt}>Pick Photo</Text></TouchableOpacity>
        <TouchableOpacity style={styles.btn} onPress={takePhoto}><Text style={styles.btnTxt}>Take Photo</Text></TouchableOpacity>
      </View>
      <TouchableOpacity style={[styles.saveBtn,{marginTop:16}]} onPress={add}><Text style={{color:'#fff'}}>Save Expense</Text></TouchableOpacity>
      <TouchableOpacity style={[styles.saveBtn,{backgroundColor:'#555', marginTop:8}]} onPress={exportNow}><Text style={{color:'#fff'}}>Export Excel</Text></TouchableOpacity>
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  container:{flex:1, padding:12, backgroundColor:'#fff'},
  label:{fontWeight:'600', marginTop:8},
  input:{borderWidth:1, borderColor:'#ddd', padding:8, borderRadius:6, marginTop:6},
  btn:{padding:10, borderWidth:1, borderColor:'#1976D2', borderRadius:6, marginTop:12},
  btnTxt:{color:'#1976D2'},
  saveBtn:{backgroundColor:'#1976D2', padding:12, borderRadius:8, alignItems:'center'}
});
