
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import XLSX from 'xlsx';
import AsyncStorage from '@react-native-async-storage/async-storage';
const STORAGE_KEY = 'EXPENSES_V1';

export async function generateExcel(){
  const raw = await AsyncStorage.getItem(STORAGE_KEY);
  const expenses = raw ? JSON.parse(raw) : [];
  // Build simple workbook with sheets requested
  const wb = XLSX.utils.book_new();
  // Summary sheet
  const summary = [['Date','Category','Amount','Purpose']];
  expenses.forEach(e=> summary.push([e.date, e.category, e.amount, e.purpose||'']));
  const ws = XLSX.utils.aoa_to_sheet(summary);
  XLSX.utils.book_append_sheet(wb, ws, 'Summary');
  // Other simple sheets
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['Local Conveyance'],['(Auto-generated)']]), 'Local Conveyance');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['Outstation']]), 'Outstation');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['Other Claims']]), 'Other Claims');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['BPE']]), 'BPE');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['Other Claims Details']]), 'Other Claims Details');
  const wbout = XLSX.write(wb, {type:'base64', bookType:'xlsx'});
  const fname = FileSystem.documentDirectory + 'Expense_Report_' + (new Date().toISOString().slice(0,10)) + '.xlsx';
  await FileSystem.writeAsStringAsync(fname, wbout, {encoding: FileSystem.EncodingType.Base64});
  // share
  if(await Sharing.isAvailableAsync()){
    await Sharing.shareAsync(fname);
  }
  return fname;
}
